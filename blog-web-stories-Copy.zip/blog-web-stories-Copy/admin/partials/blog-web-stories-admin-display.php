<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://https://dightinfotech.com/
 * @since      1.0.0
 *
 * @package    Blog_Web_Stories
 * @subpackage Blog_Web_Stories/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
