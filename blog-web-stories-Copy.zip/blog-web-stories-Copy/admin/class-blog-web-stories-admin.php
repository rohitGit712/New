<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://https://dightinfotech.com/
 * @since      1.0.0
 *
 * @package    Blog_Web_Stories
 * @subpackage Blog_Web_Stories/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Blog_Web_Stories
 * @subpackage Blog_Web_Stories/admin
 * @author     dightinfotech <dightinfotech@gmail.com>
 */
use \Firebase\JWT\JWT;
use Google\Auth\OAuth2;
use Google\Auth\Credentials\ServiceAccountCredentials;
use Google\Client;
use Google\Service\Indexing;

class Blog_Web_Stories_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Blog_Web_Stories_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Blog_Web_Stories_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/blog-web-stories-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Blog_Web_Stories_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Blog_Web_Stories_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/blog-web-stories-admin.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script('google-platform', 'https://apis.google.com/js/platform.js', array(), null, true);
	}


	public function add_stories_admin_menu() {
		add_menu_page(
			'Web Stories',            // Page title
			'Web Stories',            // Menu title
			'manage_options',     // Capability
			'stories',            // Menu slug
			[$this , 'display_stories_page'], // Function to display the page content
			plugin_dir_url(__FILE__) . '/web-stories.png', // Icon (choose an appropriate icon)
			6                     // Position
		);	
	}

	public function resize_menu_icon() {
		?>
		<style>
			#adminmenu .toplevel_page_stories img {
				width: 20px;
				height: 20px;
				margin-top: -3px;
				filter: grayscale(100%) brightness(0) invert(1);
    			mix-blend-mode: lighten;
			}
		</style>
		<?php
	}
	
	public function display_stories_page() {
		$plugin_url = plugins_url('', __FILE__);
		?>
		<div class="wrap">
			<h1 class="web-stories-heading">
				<span class="heading-icon">📚</span> Web Stories
			</h1>
			<div id="stories-container">
				<?php
				// Modify the query to include a meta query
				$args = array(
					'post_type' => 'post',  // Or replace with a custom post type if needed
					'posts_per_page' => -1,
					'meta_query' => array(
						array(
							'key' => '_show_on_web_stories',
							'value' => '1', // Only get posts where this meta key is '1'
							'compare' => '='
						)
					)
				);
	
				$query = new WP_Query($args);
	
				if ($query->have_posts()) :
					while ($query->have_posts()) : $query->the_post(); ?>
						<div class="story" data-id="<?php the_ID(); ?>" style="background-image: url('<?php echo get_the_post_thumbnail_url(); ?>');">
							<div class="story-image">
								<?php if (has_post_thumbnail()) : ?>
									<!-- Image is now the background, so you can remove this if not needed -->
									<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="story-img">
								<?php endif; ?>
							</div>
							<div class="story-info">
								<h2 class="story-title"><?php the_title(); ?></h2>
								<p class="story-description"><?php echo wp_trim_words(get_the_excerpt(), 3, '...'); ?></p>
								<a href="<?php the_permalink(); ?>" class="read-more">Read More</a>
							</div>
						</div>
					<?php endwhile;
					wp_reset_postdata();
				else :
					echo '<div class="no-stories">No stories found!</div>';
				endif;
				?>
			</div>
		</div>
	
		<style>
			.web-stories-heading {
				font-size: 48px;
				font-weight: 700;
				color: #2c3e50;
				text-align: center;
				margin-bottom: 40px;
				position: relative;
				display: inline-block;
				text-transform: uppercase;
				letter-spacing: 2px;
				font-family: 'Arial', sans-serif;
			}
	
			.web-stories-heading .heading-icon {
				font-size: 36px;
				margin-right: 15px;
				vertical-align: middle;
			}
	
			.web-stories-heading:after {
				content: '';
				position: absolute;
				bottom: -10px;
				left: 50%;
				transform: translateX(-50%);
				width: 50px;
				height: 5px;
				background: #0073aa;
				border-radius: 50px;
			}
	
			#stories-container {
				display: grid;
				grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
				gap: 20px;
				padding: 20px;
			}
	
			.story {
				position: relative;
				background-size: cover; /* Make sure the image covers the entire box */
				background-position: center; /* Center the background image */
				border-radius: 12px;
				box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
				overflow: hidden;
				transition: transform 0.3s ease, box-shadow 0.3s ease;
				min-height: 400px; /* Set a minimum height for the story box */
				cursor: pointer;
			}
	
			.story:hover {
				transform: translateY(-5px);
			}

			.story::before {
				content: "";
				position: absolute;
				top: 0;
				left: 0;
				width: 100%;
				height: 100%;
				background: rgba(0, 0, 0, 0);
				transition: background 0.6s ease;
			}

			.story:hover::before {
				background: rgba(0, 0, 0, 0.40);
			}

			.story-image {
				width: 100%;
				height: 100%; /* Allow the image to take full height */
				position: absolute;
				top: 0;
				left: 0;
				right: 0;
				bottom: 0;
				visibility: hidden; /* Hide the original image since we now have a background */
			}
	
			.story-info {
				position: absolute;
				bottom: 20px;
				left: 20px;
				right: 20px;
				background: linear-gradient(180deg, rgb(255 244 244 / 50%) 0%, rgb(34 30 30 / 80%) 100%);
				color: white;
				padding: 15px;
				border-radius: 8px;
				border-radius: 12px;
			}
	
			.story-title {
				font-size: 20px;
				font-weight: 700;
				margin-bottom: 15px;
			}
	
			.story-description {
				font-size: 16px;
				margin-bottom: 20px;
			}
	
			.read-more {
				font-weight: bold;
				color: white;
				text-decoration: none;
				transition: color 0.3s ease;
			}
	
			.read-more:hover {
				color: #0073aa;
				text-decoration: underline;
			}
	
			.no-stories {
				text-align: center;
				font-size: 18px;
				color: #666;
			}
		</style>
	
		<script>
			document.addEventListener('DOMContentLoaded', function () {
				const pluginUrl = '<?php echo esc_url(plugins_url('blog-web-stories/story-view.php')); ?>';
				document.querySelectorAll('.story').forEach(story => {
					story.addEventListener('click', () => {
						const postId = story.dataset.id;
						window.location.href = `${pluginUrl}?post_id=${postId}`;
					});
				});
			});
		</script>
		<?php
	}

	// Show on web Stories ---------------------------------

	// Add a custom checkbox meta box
	public function add_web_stories_checkbox_meta_box() {
		add_meta_box(
			'web_stories_checkbox_meta_box', // Unique ID
			'Show on Web Stories', // Box title
			[$this , 'render_web_stories_checkbox_meta_box'], // Content callback
			'post', // Post type
			'side' // Position: 'side', 'normal', or 'advanced'
		);
	}

	public function render_web_stories_checkbox_meta_box($post) {
		// Add a nonce field for security
		wp_nonce_field('web_stories_checkbox_nonce_action', 'web_stories_checkbox_nonce');
	
		// Retrieve the existing value (if any)
		$value = get_post_meta($post->ID, '_show_on_web_stories', true);
		?>
		<label for="show_on_web_stories">
			<input type="checkbox" id="show_on_web_stories" name="show_on_web_stories" value="1" <?php checked($value, '1'); ?> />
			Show on Web Stories
		</label>
		<?php
	}

	// Render the checkbox meta box

	// Save the checkbox value
	public function save_web_stories_checkbox_meta_box($post_id) {
		// Check if our nonce is set.
		if (!isset($_POST['web_stories_checkbox_nonce'])) {
			return;
		}

		// Verify the nonce.
		if (!wp_verify_nonce($_POST['web_stories_checkbox_nonce'], 'web_stories_checkbox_nonce_action')) {
			return;
		}

		// Check if this is an autosave.
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		// Check the user's permissions.
		if (!current_user_can('edit_post', $post_id)) {
			return;
		}

		// Save or delete the checkbox value.
		$checkbox_value = isset($_POST['show_on_web_stories']) ? '1' : '0';
		update_post_meta($post_id, '_show_on_web_stories', $checkbox_value);
	}


	// Add a custom meta box to the post edit screen
	public function add_custom_meta_box() {
		add_meta_box(
			'custom_meta_box_id',
			'Select Number of Stories',
			[$this , 'render_custom_meta_box'],
			'post', // Change to your post type if needed
			'side' // Position: 'side', 'normal', or 'advanced'
		);

		// Render the select field
		
	}

	public function render_custom_meta_box($post) {
		wp_nonce_field('custom_meta_box_nonce', 'custom_meta_box_nonce');
	
		// Retrieve current value or set default to 10 if not set
		$stories_value = get_post_meta($post->ID, '_number_of_stories', true);
		$stories_value = $stories_value !== '' ? $stories_value : 10; // Default to 10 if no value exists
		?>
		<label for="number_of_stories">Select number of stories (1-10):</label>
		<select name="number_of_stories" id="number_of_stories">
			<?php for ($i = 1; $i <= 10; $i++): ?>
				<option value="<?php echo $i; ?>" <?php selected($stories_value, $i); ?>><?php echo $i; ?></option>
			<?php endfor; ?>
		</select>
		<?php
	}

	// Save the number of stories value when the post is saved

	public function save_custom_meta_box($post_id) {
		// Check nonce
		if (!isset($_POST['custom_meta_box_nonce']) || !wp_verify_nonce($_POST['custom_meta_box_nonce'], 'custom_meta_box_nonce')) {
			return;
		}

		// Check if the user has permissions to save data
		if (!current_user_can('edit_post', $post_id)) {
			return;
		}

		// Save the number of stories value
		if (isset($_POST['number_of_stories']) && is_numeric($_POST['number_of_stories'])) {
			$stories_value = intval($_POST['number_of_stories']);
			if ($stories_value >= 1 && $stories_value <= 10) {
				update_post_meta($post_id, '_number_of_stories', $stories_value);
			}
		}
	}

	// Save links in one table --------------------------

	public function save_webstorie_link($post_id) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'webstorie_links';
	
		// Prevent auto-save from triggering the function
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}
	
		// Check user permissions
		if (!current_user_can('edit_post', $post_id)) {
			return;
		}
	
		// Check if it's a valid post type and is being published
		if (get_post_type($post_id) === 'post') {
			// Only generate the link for published posts or when restoring from trash
			if (get_post_status($post_id) === 'publish' || get_post_status($post_id) === 'draft') {
				// Check if the meta box _show_on_web_stories is checked
				$show_on_web_stories = get_post_meta($post_id, '_show_on_web_stories', true);
	
				if ($show_on_web_stories) {
					// Generate the dynamic link
					$link = home_url("/wp-content/plugins/blog-web-stories/story-view.php?post_id=$post_id");
	
					// Check if the link already exists in the table
					$existing_link = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table_name WHERE post_id = %d", $post_id));
	
					if ($existing_link) {
						// Update the existing link
						$updated = $wpdb->update(
							$table_name,
							array('link' => $link),
							array('post_id' => $post_id)
						);
	
						if ($updated === false) {
							error_log('Update failed: ' . $wpdb->last_error);
						}
					} else {
						// Insert the new link
						$inserted = $wpdb->insert(
							$table_name,
							array(
								'post_id' => $post_id,
								'link' => $link,
							)
						);
	
						if ($inserted === false) {
							error_log('Insert failed: ' . $wpdb->last_error);
						}
					}
				}
			}
		}
	}
		
		
	// Delete Link ----------------------------

	public function delete_webstorie_link($post_id) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'webstorie_links';
	
		// Check if the post type is 'post' before proceeding
		if (get_post_type($post_id) === 'post') {
			// Delete the link associated with the post_id
			$deleted = $wpdb->delete(
				$table_name,
				array('post_id' => $post_id)
			);
	
			if ($deleted === false) {
				error_log('Delete failed: ' . $wpdb->last_error);
			}
		}
	}

// ---------------------------------------	SiteMap ---------------------------------------

	public function my_custom_sitemap() {
		if (isset($_GET['sitemap'])) {
			header('Content-Type: application/xml; charset=utf-8');
			echo $this->my_generate_sitemap(); // Use $this-> to access the method
			exit;
		}
	}

	public function my_generate_sitemap() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'webstorie_links';
	
		// Fetch post IDs with the _show_on_web_stories meta key set to true
		$post_ids = $wpdb->get_col("
			SELECT post_id 
			FROM $wpdb->postmeta 
			WHERE meta_key = '_show_on_web_stories' 
			AND meta_value = '1'
		");
	
		// Fetch web story links from the custom table for the selected post IDs
		$web_stories = $wpdb->get_results(
			$wpdb->prepare("SELECT post_id, link FROM $table_name WHERE post_id IN (" . implode(',', array_fill(0, count($post_ids), '%d')) . ")", $post_ids)
		);
	
		$urls = [];
		foreach ($web_stories as $story) {
			$post_modified = get_post_modified_time('Y-m-d', false, $story->post_id);
			
			$urls[] = [
				'loc' => esc_url($story->link),
				'lastmod' => esc_html($post_modified),
				'changefreq' => 'daily',
				'priority' => '0.8'
			];
		}
	
		// Generate the XML for the sitemap
		$sitemap = '<?xml version="1.0" encoding="UTF-8"?>';
		$sitemap .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"';
		$sitemap .= ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"';
		$sitemap .= ' xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">';
	
		foreach ($urls as $url) {
			$sitemap .= '<url>';
			$sitemap .= '<loc>' . esc_url($url['loc']) . '</loc>';
			$sitemap .= '<lastmod>' . esc_html($url['lastmod']) . '</lastmod>';
			$sitemap .= '<changefreq>' . esc_html($url['changefreq']) . '</changefreq>';
			$sitemap .= '<priority>' . esc_html($url['priority']) . '</priority>';
			$sitemap .= '</url>';
		}
	
		$sitemap .= '</urlset>';
		return $sitemap;
	}


// 04-11-2024 ----------------------------------------

	public function cws_generate_web_story($post_id) {
		// Only run on specific post types (e.g., 'post')
		if (get_post_type($post_id) != 'post') {
			return;
		}
	
		// Get post content
		$post = get_post($post_id);
		$title = get_the_title($post);
		$content = apply_filters('the_content', $post->post_content);
		$content_parts = explode("\n\n", $content); // Split content into paragraphs
	
		// Start building HTML
		ob_start(); ?>
		<!doctype html>
		<html ⚡>
		<head>
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
			<link rel="canonical" href="https://example.com/canonical-url">
			<title><?php echo esc_html($title); ?></title>
			<style amp-custom>
				/* Add any custom styles here */
			</style>
			<style amp-boilerplate>
				body {
					-webkit-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
					-moz-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
					-ms-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
					animation: -amp-start 8s steps(1, end) 0s 1 normal both;
				}
	
				@-webkit-keyframes -amp-start {
					from { visibility: hidden; }
					to { visibility: visible; }
				}
	
				@-moz-keyframes -amp-start {
					from { visibility: hidden; }
					to { visibility: visible; }
				}
	
				@-ms-keyframes -amp-start {
					from { visibility: hidden; }
					to { visibility: visible; }
				}
	
				@keyframes -amp-start {
					from { visibility: hidden; }
					to { visibility: visible; }
				}
			</style>
			<noscript>
				<style amp-boilerplate>
					body {
						-webkit-animation: none;
						-moz-animation: none;
						-ms-animation: none;
						animation: none;
					}
				</style>
			</noscript>
		</head>
		<body>
			<amp-story 
				standalone 
				poster-portrait-src="https://example.com/poster.jpg" 
				publisher="Your Publisher Name" 
				publisher-logo-src="https://example.com/logo.png" 
				title="<?php echo esc_html($title); ?>">
				
				<?php foreach ($content_parts as $index => $part): ?>
					<amp-story-page id="page-<?php echo $index + 1; ?>">
						<amp-story-grid-layer template="fill">
							<amp-img src="https://example.com/image<?php echo $index + 1; ?>.jpg" layout="fill" alt="Image Description"></amp-img>
						</amp-story-grid-layer>
						<amp-story-grid-layer template="vertical">
							<h1><?php echo esc_html($title); ?></h1>
							<p><?php echo esc_html(trim($part)); ?></p>
						</amp-story-grid-layer>
					</amp-story-page>
				<?php endforeach; ?>
			</amp-story>
		</body>
		</html>
		<?php
	
		// Output the generated HTML
		$html_output = ob_get_clean();
	
		// Define file path
		$stories_dir = plugin_dir_path(__FILE__) . 'stories/';
		$file_path = $stories_dir . sanitize_title($title) . '.html';
	
		// Check if the directory exists, if not, create it
		if (!is_dir($stories_dir)) {
			if (mkdir($stories_dir, 0755, true)) {
				error_log("Directory created: " . $stories_dir);
			} else {
				error_log("Failed to create directory: " . $stories_dir);
				return; // Stop execution if directory creation fails
			}
		}
	
		// Write HTML to file
		if (file_put_contents($file_path, $html_output) === false) {
			error_log("Failed to write file: " . $file_path);
		}
	
		// Optionally, return the path to the generated file
		return $file_path;
	}


// ---------------------------------- indexing  ---------------------------------- 
	public function send_url_to_google_indexing($post_id) {
		$url = home_url("/wp-content/plugins/blog-web-stories/story-view.php?post_id=$post_id");
		$this->send_google_indexing_request($url);
	}

	public function send_google_indexing_request($url) {

		// Path to your service account JSON key
		$keyFilePath = plugin_dir_path(__FILE__) . 'link-indexing.json'; 
		
		// Create a new Google Client
		$client = new Google_Client();
		$client->setAuthConfig($keyFilePath);
		$client->addScope('https://www.googleapis.com/auth/indexing');
		
		// Create the Indexing API service
		$service = new Google_Service_Indexing($client);
		
		try {
			// Prepare the request to push the URL to the indexing queue
			$urlNotification = new Google_Service_Indexing_UrlNotification();
			$urlNotification->setUrl($url);
			$urlNotification->setType('URL_UPDATED');  // or 'URL_REMOVED' if you want to remove the URL from index
		
			// Submit the URL for indexing
			$response = $service->urlNotifications->publish($urlNotification);
			return $response;
			// echo "URL indexed successfully: " . json_encode($response);

		} catch (Google_Service_Exception $e) {
			echo 'Service Exception: ' . $e->getMessage();
			echo '<br><pre>';
			print_r($e->getErrors());
			echo '</pre>';
		} catch (Exception $e) {
			echo 'Exception: ' . $e->getMessage();
		}

	}

	public function dynamic_favicon() {
		$custom_logo_id = get_theme_mod('custom_logo');
		$custom_logo_url = $custom_logo_id ? wp_get_attachment_image_url($custom_logo_id, 'full') : '';
		// Output the favicon
		echo '<link rel="icon" type="image/x-icon" href="' . $custom_logo_url . '">';
	}	

}
